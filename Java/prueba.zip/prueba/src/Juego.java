import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.Random;

public class Juego {
    private JPanel panel_juego;
    private JPanel panel_cabecera;
    private JLabel label_titulo;
    private JPanel panel_central;
    private JPanel panel_matriz;
    private JPanel panel_ventanas;
    private JPanel panel_ventana_central;
    private JPanel panel_ventanas_derecha;
    private JPanel panel_ventanas_izquierda;
    private JPanel panel_fondo_para_la_ventana_que_no_tengo_ni_idea_porque;
    private JLabel label_guardada;
    private JPanel panel_guardada;
    private JPanel panel_interior_guardado;
    private JPanel panel_pausa;
    private JPanel panel_ventanas_pequenyas;
    private JLabel label_interior_guardada;
    private JLabel label_pausa;
    private JPanel panel_puntos;
    private JPanel panel_nivel;
    private JPanel panel_linea;
    private JLabel label_puntos;
    private JPanel panel_interior_puntos;
    private JLabel label_interior_puntos;
    private JPanel panel_interior_nivel;
    private JLabel label_interior_nivel;
    private JLabel label_nivel;
    private JPanel panel_interior_linea;
    private JLabel label_linea;
    private JLabel label_interior_linea;
    private JPanel panel_fondo_siguiente;
    private JPanel panel_siguiente;
    private JLabel label_siguiente;
    private JPanel panel_interior_siguiente;
    private JLabel label_siguiente_1;
    private JLabel label_siguiente_2;
    private JLabel label_siguiente_3;
    private int[] posicionPieza;

    public Juego() {
        panel_juego.setPreferredSize(new Dimension(720, 1280));
        panel_juego.setSize(720, 1280);

        panel_cabecera.setSize(new Dimension(panel_juego.getWidth(), panel_juego.getHeight() / 15));
        panel_central.setSize(new Dimension(panel_juego.getWidth(), panel_juego.getHeight() - 100));

        panel_juego.add(panel_cabecera);
        panel_juego.add(panel_central);

        int[][] matrizArray = new int[20][10];

        try {
            Font archivoBlack = Font.createFont(Font.TRUETYPE_FONT, new File("src/fuentes/Archivo_Black/ArchivoBlack-Regular.ttf"));
            Font openSans = Font.createFont(Font.TRUETYPE_FONT, new File("src/fuentes/Open_Sans/static/OpenSans-Regular.ttf"));
            Font bungee = Font.createFont(Font.TRUETYPE_FONT, new File("src/fuentes/Bungee/Bungee-Regular.ttf"));

            openSans.deriveFont(20f);
            bungee.deriveFont(30f);
            archivoBlack.deriveFont(40f);

            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(openSans);
            ge.registerFont(bungee);
            ge.registerFont(archivoBlack);

            System.out.println("Se ha cargado la fuente de Open Sans, Archivo Black, y Bungee a la pantalla Juego");
            label_titulo.setFont(new Font("Archivo Black", Font.PLAIN, 40));
            label_guardada.setFont(new Font("Bungee", Font.PLAIN, 20));
            label_puntos.setFont(new Font("Bungee", Font.PLAIN, 20));
            label_linea.setFont(new Font("Bungee", Font.PLAIN, 20));
            label_nivel.setFont(new Font("Bungee", Font.PLAIN, 20));
            label_siguiente.setFont(new Font("Bungee", Font.PLAIN, 20));
            label_interior_linea.setFont(new Font("Open Sans", Font.PLAIN, 20));
            label_interior_nivel.setFont(new Font("Open Sans", Font.PLAIN, 20));
            label_interior_puntos.setFont(new Font("Open Sans", Font.PLAIN, 20));
        } catch (FontFormatException | IOException e) {
            System.out.println("No se ha podido cargar las fuentes");
        }

        Icon iconoPausa = getIcon("src/imagenes/pausa.png", 48);
        label_pausa.setIcon(iconoPausa);

        generarMatriz();
        int[] randomPiezas = generarRandom();

        posicionPieza = sacarPieza(randomPiezas);

        panel_matriz.setFocusable(true);
        panel_matriz.addKeyListener(new PiezaListener());
    }

    private void generarMatriz() {
        panel_matriz.setLayout(new GridLayout(20, 10));

        Icon pixel = getIcon("src/imagenes/Pixel Matriz.png", 24);

        for (int i = 0; i < 20 * 10; i++) {
            panel_matriz.add(new JLabel(pixel));
        }
    }

    private int[] generarRandom() {
        Random random = new Random();
        int[] randomPiezas = new int[7];

        for (int i = 0; i < randomPiezas.length; i++) {
            randomPiezas[i] = random.nextInt(7);
        }

        return randomPiezas;
    }

    public int[] sacarPieza(int[] randomPiezas) {
        JLabel pieza1, pieza2, pieza3, pieza4;
        String[] rutaPiezas = {"src/imagenes/Piezas Tetris/Pieza I.png", "src/imagenes/Piezas Tetris/Pieza J.png",
                "src/imagenes/Piezas Tetris/Pieza L.png", "src/imagenes/Piezas Tetris/Pieza O.png",
                "src/imagenes/Piezas Tetris/Pieza S.png", "src/imagenes/Piezas Tetris/Pieza T.png",
                "src/imagenes/Piezas Tetris/Pieza Z.png"};
        int[] posicionPieza = new int[4];

        switch (randomPiezas[0]) {
            case 0:
                posicionPieza = new int[]{3, 4, 5, 6};

                pieza1 = (JLabel) panel_matriz.getComponent(posicionPieza[0]);
                pieza2 = (JLabel) panel_matriz.getComponent(posicionPieza[1]);
                pieza3 = (JLabel) panel_matriz.getComponent(posicionPieza[2]);
                pieza4 = (JLabel) panel_matriz.getComponent(posicionPieza[3]);

                Icon icono_pixelI = getIcon("src/imagenes/Pixeles Tetris/Pixel I.png", 24);
                pieza1.setIcon(icono_pixelI);
                pieza2.setIcon(icono_pixelI);
                pieza3.setIcon(icono_pixelI);
                pieza4.setIcon(icono_pixelI);
                break;
            case 1:
                posicionPieza = new int[]{3, 13, 14, 15};

                pieza1 = (JLabel) panel_matriz.getComponent(posicionPieza[0]);
                pieza2 = (JLabel) panel_matriz.getComponent(posicionPieza[1]);
                pieza3 = (JLabel) panel_matriz.getComponent(posicionPieza[2]);
                pieza4 = (JLabel) panel_matriz.getComponent(posicionPieza[3]);

                Icon icono_pixelJ = getIcon("src/imagenes/Pixeles Tetris/Pixel J.png", 24);
                pieza1.setIcon(icono_pixelJ);
                pieza2.setIcon(icono_pixelJ);
                pieza3.setIcon(icono_pixelJ);
                pieza4.setIcon(icono_pixelJ);
                break;
            case 2:
                posicionPieza = new int[]{5, 13, 14, 15};

                pieza1 = (JLabel) panel_matriz.getComponent(posicionPieza[0]);
                pieza2 = (JLabel) panel_matriz.getComponent(posicionPieza[1]);
                pieza3 = (JLabel) panel_matriz.getComponent(posicionPieza[2]);
                pieza4 = (JLabel) panel_matriz.getComponent(posicionPieza[3]);

                Icon icono_pixelL = getIcon("src/imagenes/Pixeles Tetris/Pixel L.png", 24);
                pieza1.setIcon(icono_pixelL);
                pieza2.setIcon(icono_pixelL);
                pieza3.setIcon(icono_pixelL);
                pieza4.setIcon(icono_pixelL);
                break;
            case 3:
                posicionPieza = new int[]{4, 5, 14, 15};

                pieza1 = (JLabel) panel_matriz.getComponent(posicionPieza[0]);
                pieza2 = (JLabel) panel_matriz.getComponent(posicionPieza[1]);
                pieza3 = (JLabel) panel_matriz.getComponent(posicionPieza[2]);
                pieza4 = (JLabel) panel_matriz.getComponent(posicionPieza[3]);

                Icon icono_pixelO = getIcon("src/imagenes/Pixeles Tetris/Pixel O.png", 24);
                pieza1.setIcon(icono_pixelO);
                pieza2.setIcon(icono_pixelO);
                pieza3.setIcon(icono_pixelO);
                pieza4.setIcon(icono_pixelO);
                break;
            case 4:
                posicionPieza = new int[]{13, 14, 4, 5};

                pieza1 = (JLabel) panel_matriz.getComponent(posicionPieza[0]);
                pieza2 = (JLabel) panel_matriz.getComponent(posicionPieza[1]);
                pieza3 = (JLabel) panel_matriz.getComponent(posicionPieza[2]);
                pieza4 = (JLabel) panel_matriz.getComponent(posicionPieza[3]);

                Icon icono_pixelS = getIcon("src/imagenes/Pixeles Tetris/Pixel S.png", 24);
                pieza1.setIcon(icono_pixelS);
                pieza2.setIcon(icono_pixelS);
                pieza3.setIcon(icono_pixelS);
                pieza4.setIcon(icono_pixelS);
                break;
            case 5:
                posicionPieza = new int[]{13, 14, 15, 4};

                pieza1 = (JLabel) panel_matriz.getComponent(posicionPieza[0]);
                pieza2 = (JLabel) panel_matriz.getComponent(posicionPieza[1]);
                pieza3 = (JLabel) panel_matriz.getComponent(posicionPieza[2]);
                pieza4 = (JLabel) panel_matriz.getComponent(posicionPieza[3]);

                Icon icono_pixelT = getIcon("src/imagenes/Pixeles Tetris/Pixel T.png", 24);
                pieza1.setIcon(icono_pixelT);
                pieza2.setIcon(icono_pixelT);
                pieza3.setIcon(icono_pixelT);
                pieza4.setIcon(icono_pixelT);
                break;
            case 6:
                posicionPieza = new int[]{3, 4, 14, 15};

                pieza1 = (JLabel) panel_matriz.getComponent(posicionPieza[0]);
                pieza2 = (JLabel) panel_matriz.getComponent(posicionPieza[1]);
                pieza3 = (JLabel) panel_matriz.getComponent(posicionPieza[2]);
                pieza4 = (JLabel) panel_matriz.getComponent(posicionPieza[3]);

                Icon icono_pixelZ = getIcon("src/imagenes/Pixeles Tetris/Pixel Z.png", 24);
                pieza1.setIcon(icono_pixelZ);
                pieza2.setIcon(icono_pixelZ);
                pieza3.setIcon(icono_pixelZ);
                pieza4.setIcon(icono_pixelZ);
                break;
        }

        label_siguiente_1.setIcon(getIcon(rutaPiezas[randomPiezas[1]]));
        label_siguiente_2.setIcon(getIcon(rutaPiezas[randomPiezas[2]]));
        label_siguiente_3.setIcon(getIcon(rutaPiezas[randomPiezas[3]]));

        return posicionPieza;
    }

    private static Icon getIcon(String filename, int tamanyo) {
        ImageIcon pixel = new ImageIcon(filename);
        return new ImageIcon(
                pixel.getImage().getScaledInstance(tamanyo, tamanyo, Image.SCALE_DEFAULT)
        );
    }

    private static Icon getIcon(String rutaPieza) {
        ImageIcon pixel = new ImageIcon(rutaPieza);
        return new ImageIcon(
                pixel.getImage().getScaledInstance(36, 24, Image.SCALE_DEFAULT)
        );
    }

    public class PiezaListener extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            super.keyPressed(e);
            ImageIcon imagenPixel = new ImageIcon("src/imagenes/Pixel Matriz.png");
            Icon pixel = new ImageIcon(
                    imagenPixel.getImage().getScaledInstance(24, 24, Image.SCALE_DEFAULT)
            );
            JLabel pieza1 = (JLabel) panel_matriz.getComponent(posicionPieza[0]);
            JLabel pieza2 = (JLabel) panel_matriz.getComponent(posicionPieza[1]);
            JLabel pieza3 = (JLabel) panel_matriz.getComponent(posicionPieza[2]);
            JLabel pieza4 = (JLabel) panel_matriz.getComponent(posicionPieza[3]);

            Icon pixelPieza = pieza1.getIcon();

            JLabel piezaDerecha = (JLabel) panel_matriz.getComponent(pillarNumeroMenor(posicionPieza) + 1);
            JLabel piezaIzquierda = (JLabel) panel_matriz.getComponent(pillarNumeroMenor(posicionPieza) - 1);
            switch (e.getKeyCode()) {
                case KeyEvent.VK_LEFT:

                    break;
                case KeyEvent.VK_RIGHT:
                    if (piezaDerecha.getIcon().equals(pixel)) {
                        JLabel pieza1_nueva = (JLabel) panel_matriz.getComponent(posicionPieza[0] + 1);
                        JLabel pieza2_nueva = (JLabel) panel_matriz.getComponent(posicionPieza[1] + 1);
                        JLabel pieza3_nueva = (JLabel) panel_matriz.getComponent(posicionPieza[2] + 1);
                        JLabel pieza4_nueva = (JLabel) panel_matriz.getComponent(posicionPieza[3] + 1);

                        pieza1.setIcon(pixel);
                        pieza2.setIcon(pixel);
                        pieza3.setIcon(pixel);
                        pieza4.setIcon(pixel);

                        pieza1_nueva.setIcon(pixelPieza);
                        pieza2_nueva.setIcon(pixelPieza);
                        pieza3_nueva.setIcon(pixelPieza);
                        pieza4_nueva.setIcon(pixelPieza);
                    }
                    break;
            }
//            if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
//                if (piezaDerecha.getIcon().equals(pixel)) {
//                    JLabel pieza1_nueva = (JLabel) panel_matriz.getComponent(posicionPieza[0] + 1);
//                    JLabel pieza2_nueva = (JLabel) panel_matriz.getComponent(posicionPieza[1] + 1);
//                    JLabel pieza3_nueva = (JLabel) panel_matriz.getComponent(posicionPieza[2] + 1);
//                    JLabel pieza4_nueva = (JLabel) panel_matriz.getComponent(posicionPieza[3] + 1);
//
//                    pieza1.setIcon(pixel);
//                    pieza2.setIcon(pixel);
//                    pieza3.setIcon(pixel);
//                    pieza4.setIcon(pixel);
//
//                    pieza1_nueva.setIcon(pixelPieza);
//                    pieza2_nueva.setIcon(pixelPieza);
//                    pieza3_nueva.setIcon(pixelPieza);
//                    pieza4_nueva.setIcon(pixelPieza);
//
//                }
//            } else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
//                if (piezaIzquierda.getIcon().equals(pixel)) {
//
//                }
//            } else if (e.getKeyCode() == KeyEvent.VK_UP) {
//
//            }
        }
    }

    private static int pillarNumeroMenor(int[] posicionPieza) {
        int numeroMenor = posicionPieza[0];
        for (int i : posicionPieza ) {
            if (numeroMenor > i) {
                numeroMenor = i;
            }
        }
        return numeroMenor;
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Juego");
        frame.setContentPane(new Juego().panel_juego);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }

    public JPanel getPanel_juego() {
        return panel_juego;
    }
}
